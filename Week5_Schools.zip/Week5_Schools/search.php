<?php

/* 
(-) search.php allows a user to search the school table on a combination of these fields.
 
 
(-) The user is not allowed to navigate directly to upload.php or search.php.
    If the user is not logged in (check by referring to a $_SESSION variable), the user is brought back to login.php.  
 */

?>