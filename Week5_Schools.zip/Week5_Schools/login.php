<?php

/* 
(-) login.php allows the user to login by providing a username and password.
(-) The password must be encrypted in the user table.
(-) Upon logging in the user is taken to the upload.php page.
 */





?>